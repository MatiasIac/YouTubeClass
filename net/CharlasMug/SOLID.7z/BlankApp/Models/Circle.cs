﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlankApp.Models
{
    public class Circle : ICircle
    {
        public string Draw()
        {
            return "o";
        }

        public void SetPoint(int x, int y)
        {
            
        }

        public void SetRadio(int radio)
        {
            
        }
    }
}
