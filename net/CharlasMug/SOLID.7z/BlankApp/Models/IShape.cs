﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlankApp.Models
{
    public interface IShape
    {
        string Draw();
    }

    public interface ICircle : IShape
    {
        //Circulo
        void SetRadio(int radio);

        void SetPoint(int x, int y);
    }
}
