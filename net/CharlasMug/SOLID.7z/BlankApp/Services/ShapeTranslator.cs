﻿using BlankApp.Models;
using SOLIDWeb.SOLID.DependencyInversion;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;

namespace SOLIDWeb.Services
{
    public class ShapeTranslator : IShapeTranslator
    {
        public readonly IShapeFactory _shapeFactory;

        public ShapeTranslator(IShapeFactory shapeFactory)
        {
            _shapeFactory = shapeFactory;
        }

        public ShapeResolver ResolveShape(string name)
        {
            var shape = _shapeFactory.GetShape(name);

            return new ShapeResolver(shape);
        }

        public class ShapeResolver
        {
            private readonly IShape _shape;

            public int Sumar(IEnumerable<int> lista)
            {
                return lista.Sum(i => i);
            }

            public ShapeResolver(IShape shape)
            {
                _shape = shape;
            }

            public string Draw() => _shape.Draw();
        }

    }
}