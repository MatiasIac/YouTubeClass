﻿using static SOLIDWeb.Services.ShapeTranslator;

namespace SOLIDWeb.Services
{
    public interface IShapeTranslator
    {
        ShapeResolver ResolveShape(string name);
    }
}