﻿using BlankApp.Models;

namespace SOLIDWeb.SOLID.DependencyInversion
{
    public interface IShapeFactory
    {
        IShape GetShape(string name);
    }
}
